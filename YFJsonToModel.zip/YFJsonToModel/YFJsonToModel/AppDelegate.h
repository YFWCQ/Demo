//
//  AppDelegate.h
//  YFJsonToModel
//
//  Created by FYWCQ on 16/8/1.
//  Copyright © 2016年 YFWCQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

