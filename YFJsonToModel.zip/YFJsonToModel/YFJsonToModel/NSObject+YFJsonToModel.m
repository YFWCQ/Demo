//
//  NSObject+YFJsonToModel.m
//  YFJsonToModel
//
//  Created by FYWCQ on 16/8/1.
//  Copyright © 2016年 YFWCQ. All rights reserved.
//

#import "NSObject+YFJsonToModel.h"
#import <objc/runtime.h>

@implementation NSObject (YFJsonToModel)

// 利用 Runtime
-(void)fy_modelSetWithDictionary:(NSDictionary *)dictionary
{
    if (dictionary == nil){
        return;
    }
    unsigned int outCount =0;
    
    Ivar*vars =class_copyIvarList([self class], &outCount);//获取到所有的成员变量列表
    //遍历所有的成员变量
    for(int i =0; i < outCount; i++) {
        Ivar ivar = vars[i];//取出第i个位置的成员变量
        const char*propertyName =ivar_getName(ivar);//获取变量名
        
        NSString*proOcName = [NSString stringWithUTF8String:propertyName];
        
        id jsonValue = [dictionary objectForKey:[proOcName stringByReplacingOccurrencesOfString:@"_" withString:@""]];
        
        object_setIvar(self, ivar,jsonValue);
    }
}

@end
