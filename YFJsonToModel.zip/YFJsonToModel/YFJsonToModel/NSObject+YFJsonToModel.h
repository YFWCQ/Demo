//
//  NSObject+YFJsonToModel.h
//  YFJsonToModel
//
//  Created by FYWCQ on 16/8/1.
//  Copyright © 2016年 YFWCQ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (YFJsonToModel)

// 利用runtime
-(void)fy_modelSetWithDictionary:(NSDictionary *)dic;

@end
