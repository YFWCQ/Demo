//
//  YFTestCell.swift
//  SwiftWorks
//
//  Created by FYWCQ on 16/11/8.
//  Copyright © 2016年 Medalands. All rights reserved.
//

import UIKit

class YFTestCell: YFBaseCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
