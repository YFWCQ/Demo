//
//  FYArrayTestModel.swift
//  SwiftWorks
//
//  Created by FYWCQ on 15/12/24.
//  Copyright © 2015年 Medalands. All rights reserved.
//

import UIKit

class FYArrayTestModel: NSObject {

    var changeStr:String?
    var tt:Array = ["123","123","123"]

    
}
