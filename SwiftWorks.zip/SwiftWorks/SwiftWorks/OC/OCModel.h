//
//  OCModel.h
//  SwiftWorks
//
//  Created by Medalands on 15/9/8.
//  Copyright (c) 2015年 Medalands. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OCModel : NSObject

+(void)testaaaaaaa;

-(void)testBbbbbbb;

@end
