//
//  OCModel.m
//  SwiftWorks
//
//  Created by Medalands on 15/9/8.
//  Copyright (c) 2015年 Medalands. All rights reserved.
//

#import "OCModel.h"

@implementation OCModel

+(void)testaaaaaaa
{
    NSLog(@"12312312======");
}

-(void)testBbbbbbb
{
    
}

@end
